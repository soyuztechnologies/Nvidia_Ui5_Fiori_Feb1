sap.ui.jsview("mickey.view.Main",{
    getControllerName: function(){
        return "mickey.controller.Main";
    },
    createContent: function(){
        
        //Syntax to create a control in UI5
        // var OBJ = new LIBRARY.CONTROL("ID",{
        //     PROP: VALUE,
        //     PROP: VALUE
        // })
        var oBtn = new sap.m.Button("idBtn",{
            text: "Click Me",
            press: function () {
                alert("welcome to the ui5");
            }
        });

        return oBtn;

    }
});