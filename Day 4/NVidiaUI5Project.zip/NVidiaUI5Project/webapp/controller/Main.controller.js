//In UI5 every Module (class) start with a module definition
//This is called AMD (Asynchronous Module Load) Syntax
//Every JS file (class or module)
// sap.ui.define(
//     ["dep1","dep2","dep3"],
//     function(oDep1, oDep2, oDep3){
//         return {};
//     }
// );
sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Spiderman) {
    'use strict';
    //extend is a keyword used in JS to create inheritence
    return Spiderman.extend("mickey.controller.Main",{
        //logic of this controller 
    });
});