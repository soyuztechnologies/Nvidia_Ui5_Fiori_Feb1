const express = require('express')
const app = express()

app.get('/', function (req, res) {
  res.send('Hello Amigo!')
})

app.get('/home', function (req, res) {
    const body = '<html><body><img src="https://www.nvidia.com/content/dam/en-zz/Solutions/about-nvidia/logo-and-brand/01-nvidia-logo-vert-500x200-2c50-p@2x.png"></body></html>'
    res.send(body)
  })

app.listen(3000)

console.log("Your web server is running on http://localhost:3000 To Stop it use Ctrl+C")