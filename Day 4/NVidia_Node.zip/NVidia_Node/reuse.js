module.exports = {
    addNumbers : function (a,b){
        console.log(a + b);
    },
    
    calcSizeArray: function (arr){
        console.log("Size of the array is ==> " + arr.length);
    },
    
    printData: function (arr){
        for (let i = 0; i < arr.length; i++) {
            const element = arr[i];
            console.log(element);
        }
    }
}