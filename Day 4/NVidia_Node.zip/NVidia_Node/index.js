var reuse = require('./reuse');
console.log("hello node js");

reuse.addNumbers(5,5);
var arrFruits = ["Apple","Cherry", "Mango"];
reuse.calcSizeArray(arrFruits);
reuse.printData(arrFruits);