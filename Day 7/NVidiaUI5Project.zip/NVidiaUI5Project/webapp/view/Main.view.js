sap.ui.jsview("mickey.view.Main",{
    getControllerName: function(){
        return "mickey.controller.Main";
    },
    createContent: function(oController){
        
        //Syntax to create a control in UI5
        // var OBJ = new LIBRARY.CONTROL("ID",{
        //     PROP: VALUE,
        //     PROP: VALUE
        // })
        var oInp = new sap.m.Input("idInp");

        var oBtn = new sap.m.Button("idBtn",{
            text: "Click Me",
            press: oController.clickMe
        });

        return [oInp,oBtn];

    }
});