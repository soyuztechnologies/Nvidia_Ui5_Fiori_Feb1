sap.ui.define([
    'sap/ui/model/json/JSONModel',
    'sap/ui/model/xml/XMLModel',
    'sap/ui/model/resource/ResourceModel'
], function(JSONModel, XMLModel, ResourceModel) {
    'use strict';
    return {
        createJSONModel: function(filePath){
            // Step 1: Create a brand-new object of the Model
            var oModel = new JSONModel()
            //oModel.setDefaultBindingMode("OneWay");
            // Step 2: Set or Load the data in the Model
            oModel.loadData(filePath);
            return oModel;
        },
        createResourceModel: function(){
            var oModel = new ResourceModel({
                bundleUrl: "i18n/i18n.properties"
            });
            return oModel;
        },
        createXMLModel: function(){
            var oModel = new XMLModel();
        }
    }
});