sap.ui.define([
    'mickey/controller/BaseController',
    'mickey/models/models'
], function(BaseController, model) {
    'use strict';
    return BaseController.extend("mickey.controller.MyXML",{
        onInit: function(){
            //alert("now my controller was instantiated");
            var oModel = model.createJSONModel("models/mockdata/employee.json");
            var oGot = model.createJSONModel("models/mockdata/employee2.json");
            //use the resource model
            var oResource = model.createResourceModel();
            this.oCore.setModel(oResource,"i18n");
            // Step 3: Make the model aware to the application/view
            //A model w/o name is called default model
            this.oCore.setModel(oModel);
            //a model with a name is called named model
            this.oCore.setModel(oGot, "got");
            //this.getView().setModel(oModel);
            // var oSal = this.getView().byId("idSal");
            // oSal.bindValue("/empStr/salary");
            this.addNumber(5,5);
            // var oSal = this.getView().byId("idCurrency");
            // oSal.bindProperty("value","/empStr/currency");

        },
        onRowSelect: function(oEvent){
            //Step 1: Use event object to extract the path of the memory
            var rowContext = oEvent.getParameter("rowContext");
            var sElementPath = rowContext.getPath();
            console.log(sElementPath);
            //Step 2: Use this path to bind to simple form - whole form can receive data
            //from the same memory from where its receiving data from rows
            var oSimple = this.getView().byId("idForm");
            //Step 3: Perform Element binding
            oSimple.bindElement(sElementPath);
        },
        onChange: function () {
           //Step 1: Get the model object
           var oModel = this.oCore.getModel();
           //Step 2: Change the data into the model
           //Model object provides SETTER and GETTER method on PATH
            console.log(oModel.getProperty("/empStr"));
        },
        onClick: function(){
            //here we want to access input object again ME->
            //Step 1: Access the view object from controller object (this)
            var oView = this.getView();
            //Step 2: From this view object we can get control object w/o appending view id
            var oControl = oView.byId("idField");
            //Step 3: Access the value of the control now
            var sText = oControl.getValue();
            alert(sText);
            return "";
        }
    });
});