//In UI5 every Module (class) start with a module definition
//This is called AMD (Asynchronous Module Load) Syntax
//Every JS file (class or module)
// sap.ui.define(
//     ["dep1","dep2","dep3"],
//     function(oDep1, oDep2, oDep3){
//         return {};
//     }
// );
sap.ui.define([
    'mickey/controller/BaseController'
], function(BaseController) {
    'use strict';
    //extend is a keyword used in JS to create inheritence
    return BaseController.extend("mickey.controller.Main",{
        //logic of this controller 
        clickMe: function () {
            //alert("welcome to the ui5");
            //Step 1: Get access to the object of Application
            var oCore = sap.ui.getCore();
            //Step 2: Get Access to the Control by Control ID
            var oInp = oCore.byId("idInp");
            //Step 3: Get the value of the input control
            var sValue = oInp.getValue();
            //Step 4: Show to user
            alert(sValue);
        }

    });
});