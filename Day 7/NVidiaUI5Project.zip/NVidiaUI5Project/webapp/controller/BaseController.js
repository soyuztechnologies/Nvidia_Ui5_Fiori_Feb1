sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    //Extend keyword is used to do inheritence
    return Controller.extend("mickey.controller.BaseController",{
        x: "anubhav",
        oCore: sap.ui.getCore(),
        addNumber: function(a,b){
            console.log( a + b );
        }
    });
});