sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    return Controller.extend("mickey.controller.MyXML",{
        onInit: function(){
            //alert("now my controller was instantiated");
            // Step 1: Create a brand-new object of the Model
            var oModel = new sap.ui.model.json.JSONModel()
            
            // Step 2: Set or Load the data in the Model
            oModel.loadData("models/mockdata/employee.json");

            // Step 3: Make the model aware to the application/view
            sap.ui.getCore().setModel(oModel);
            //this.getView().setModel(oModel);
        },
        onClick: function(){
            //here we want to access input object again ME->
            //Step 1: Access the view object from controller object (this)
            var oView = this.getView();
            //Step 2: From this view object we can get control object w/o appending view id
            var oControl = oView.byId("idField");
            //Step 3: Access the value of the control now
            var sText = oControl.getValue();
            alert(sText);
            return "";
        }
    });
});