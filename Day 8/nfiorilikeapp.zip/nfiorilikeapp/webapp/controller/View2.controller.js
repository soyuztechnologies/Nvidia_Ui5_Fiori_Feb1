sap.ui.define([
    'nvidia/sd/sales/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("nvidia.sd.sales.controller.View2",{
        onInit: function () {
            
        },
        onBack: function(){
            //Step 1: Get the control object of parent Container
            var oAppCon = this.getView().getParent();
            //Step 2: Mother is responsible for nav, App Con to API
            oAppCon.to("idView1");

        }
    });
});