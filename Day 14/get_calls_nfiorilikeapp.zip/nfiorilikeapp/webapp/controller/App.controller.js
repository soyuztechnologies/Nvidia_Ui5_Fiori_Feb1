sap.ui.define([
    'nvidia/sd/sales/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("nvidia.sd.sales.controller.App",{
        onInit: function () {
            
        }
    });
});